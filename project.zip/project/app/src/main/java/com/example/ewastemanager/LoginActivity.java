package com.example.ewastemanager;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class LoginActivity extends AppCompatActivity {
    public Button loginBtn;
    public EditText email;
    public EditText password;
    private String emailStr,passwordStr;
    private FirebaseAuth mAuth;
    public FirebaseAuth.AuthStateListener authStateListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mAuth = FirebaseAuth.getInstance();
        email=findViewById(R.id.email);
        password=findViewById(R.id.password);
        loginBtn=findViewById(R.id.loginBtn);

        authStateListener=new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser firebaseUser= mAuth.getCurrentUser();
                if (firebaseUser!=null){
                    Toast.makeText(LoginActivity.this,"You are logged in",Toast.LENGTH_SHORT).show();
                    Intent i=new Intent(LoginActivity.this,MainActivity.class);
                    startActivity(i);
                }
                else {
                    Toast.makeText(LoginActivity.this,"Please log in",Toast.LENGTH_SHORT).show();
                }
            }
        };
        loginBtn.setOnClickListener(v->
        { emailStr=email.getText().toString();
        passwordStr=password.getText().toString();
        if (emailStr.isEmpty()){
            email.setError("Please enter your email address");
            email.requestFocus();
        }
        else if (passwordStr.isEmpty()){
            password.setError("Please Enter your password");
            password.requestFocus();
        }
        else if (emailStr.isEmpty()&&passwordStr.isEmpty())
        {
            Toast.makeText(LoginActivity.this,"All fields are needed",Toast.LENGTH_SHORT).show();
        }
        else if(!emailStr.isEmpty()&&!passwordStr.isEmpty()){
            mAuth.signInWithEmailAndPassword(emailStr, passwordStr).addOnCompleteListener(LoginActivity.this, new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()){
                        //if login is successful, update the UI with the user's information
                        
                    }
                }
            });
        }
        else {
            Toast.makeText(LoginActivity.this,"Error occurred",Toast.LENGTH_SHORT).show();
        }
        });
    }



}
